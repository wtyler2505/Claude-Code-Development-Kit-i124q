---
name: swarm-run
description: Spawn a transient swarm (architect, coder, tester, auditor) for a single task and auto-destruct afterwards.
argument-hint: "<task description>"
---
## Swarm‑Run

Invokes multiple specialists in parallel, aggregates their outputs, returns a digest.
