---
name: hive-status
description: Show running hive sessions, workers and memory stats.
---
## Hive Status
