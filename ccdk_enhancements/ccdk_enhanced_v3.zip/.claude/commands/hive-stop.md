---
name: hive-stop
description: Gracefully shut down a Hive‑Mind session and compact memory.
argument-hint: "<session-name>"
---
## Hive Stop
