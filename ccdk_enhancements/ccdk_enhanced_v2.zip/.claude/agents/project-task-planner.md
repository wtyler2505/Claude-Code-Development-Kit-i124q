---
name: project-task-planner
description: Breaks down epics into tasks with priorities and estimations.
---
Generates Gantt‑style breakdowns, dependency graphs and risk assessments.
