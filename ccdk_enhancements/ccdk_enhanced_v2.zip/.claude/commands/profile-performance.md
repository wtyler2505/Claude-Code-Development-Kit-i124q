---
name: profile-performance
description: Profile code using py-spy/node --prof and suggest optimisations.
allowed-tools: ["bash","python"]
---
## Performance Profiling

Generates CPU & memory flamegraphs, pinpoints bottlenecks and outputs optimisation tips.
