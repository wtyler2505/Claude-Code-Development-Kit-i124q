---
name: scaffold-command
description: Generate a new slash-command template with front‑matter and boilerplate.
allowed-tools: ["bash","python"]
argument-hint: "<command-name>"
---
## Scaffold Command

Asks user for description, allowed-tools and saves a .md template into .claude/commands/.
