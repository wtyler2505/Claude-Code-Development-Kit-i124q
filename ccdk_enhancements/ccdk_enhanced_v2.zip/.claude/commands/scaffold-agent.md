---
name: scaffold-agent
description: Generate a new agent template with recommended front‑matter.
argument-hint: "<agent-name>"
---
## Scaffold Agent

Interactive prompt to create .claude/agents/<name>.md with best‑practice structure.
