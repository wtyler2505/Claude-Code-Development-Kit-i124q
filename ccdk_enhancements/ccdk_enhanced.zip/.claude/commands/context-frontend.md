---
name: context-frontend
description: Load only frontend‑related docs and code for targeted assistance.
---
# Frontend Context Loader

Reads `frontend/` directories + `docs/frontend*` to prime Claude’s context quickly.
