---
name: git-create-pr
description: Automate branch push and pull‑request creation with summary and reviewer assignment.
allowed-tools: ["bash"]
argument-hint: "<branch> <title>"
---
## Git Create PR

Uses GitHub MCP to open a Pull Request, fills description with AI‑generated changelog and tags reviewers.
