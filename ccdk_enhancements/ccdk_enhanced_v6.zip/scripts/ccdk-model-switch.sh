#!/usr/bin/env bash
echo "$1" > .current_model
echo "Model preference set to $1"
