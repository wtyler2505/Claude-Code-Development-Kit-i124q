---
name: generate-changelog
description: Generate or update CHANGELOG.md from commit messages since last tag.
allowed-tools: ["bash","python"]
---
Uses conventional commits to append to CHANGELOG.md and create a PR.
